---
name: Large puzzle generation
description: Why larger Queens boards avoid random uniqueness search
---

Boards above 10×10 should avoid random uniqueness search because the backtracking solver can block an API request for many seconds. Use a bounded constructive generator seeded from a valid queen arrangement and flood-fill connected regions.

**Why:** A 20×20 random generation attempt timed out before a fallback could run.

**How to apply:** If the supported maximum size increases, keep large-board generation bounded and preserve connected, balanced regions rather than raising the random-attempt limit.