export interface PuzzleGrid {
  size: number;
  regions: number[][];
  solution: number[][];
  generatedIn: number;
}

export type PuzzleDifficulty = "easy" | "medium" | "hard";

function generateRandomRegions(n: number, difficulty: PuzzleDifficulty): number[][] {
  const grid: number[][] = Array.from({ length: n }, () => Array(n).fill(-1));
  const regions: Array<Array<[number, number]>> = [];

  // Place one seed per region
  for (let rId = 0; rId < n; rId++) {
    let placed = false;
    while (!placed) {
      const x = Math.floor(Math.random() * n);
      const y = Math.floor(Math.random() * n);
      if (grid[x][y] === -1) {
        grid[x][y] = rId;
        regions.push([[x, y]]);
        placed = true;
      }
    }
  }

  // Expand regions until every cell is assigned
  let unassigned = n * n - n;
  const MAX_ITERS = n * n * 20;
  let iters = 0;

  while (unassigned > 0 && iters < MAX_ITERS) {
    iters++;
    const availableRegions = regions
      .map((region, rId) => ({
        rId,
        hasFrontier: region.some(([x, y]) =>
          [
            [x + 1, y],
            [x - 1, y],
            [x, y + 1],
            [x, y - 1],
          ].some(([nx, ny]) => nx >= 0 && nx < n && ny >= 0 && ny < n && grid[nx][ny] === -1)
        ),
      }))
      .filter(({ hasFrontier }) => hasFrontier)
      .map(({ rId }) => rId);

    if (availableRegions.length === 0) break;

    const rId =
      difficulty === "easy"
        ? availableRegions[iters % availableRegions.length]
        : availableRegions[Math.floor(Math.random() * availableRegions.length)];
    const region = regions[rId];
    const [baseX, baseY] = region[Math.floor(Math.random() * region.length)];

    const neighbors: Array<[number, number]> = [
      [baseX + 1, baseY],
      [baseX - 1, baseY],
      [baseX, baseY + 1],
      [baseX, baseY - 1],
    ];

    const valid = neighbors.filter(
      ([nx, ny]) => nx >= 0 && nx < n && ny >= 0 && ny < n && grid[nx][ny] === -1
    );

    if (valid.length > 0) {
      const [nx, ny] = valid[Math.floor(Math.random() * valid.length)];
      grid[nx][ny] = rId;
      region.push([nx, ny]);
      unassigned--;
    }
  }

  // Fallback: assign any remaining unassigned cells to region 0
  for (let i = 0; i < n; i++) {
    for (let j = 0; j < n; j++) {
      if (grid[i][j] === -1) {
        grid[i][j] = 0;
        regions[0].push([i, j]);
      }
    }
  }

  return grid;
}

/**
 * Backtracking solver. Places one queen per row.
 * Stops after finding more than `limit` solutions for efficiency.
 */
function solveQueens(
  n: number,
  regions: number[][],
  row: number,
  usedCols: Set<number>,
  usedRegions: Set<number>,
  placement: number[][],
  solutions: number[][][],
  limit: number
): void {
  if (solutions.length > limit) return;

  if (row === n) {
    // Deep copy the current placement as a solution
    solutions.push(placement.map((r) => [...r]));
    return;
  }

  for (let col = 0; col < n; col++) {
    if (usedCols.has(col)) continue;

    const regionId = regions[row][col];
    if (usedRegions.has(regionId)) continue;

    // Check adjacency with all previously placed queens
    let adjacent = false;
    for (let prevRow = 0; prevRow < row; prevRow++) {
      const prevCol = placement[prevRow].indexOf(1);
      if (prevCol === -1) continue;
      const rowDiff = Math.abs(row - prevRow);
      const colDiff = Math.abs(col - prevCol);
      if (rowDiff <= 1 && colDiff <= 1) {
        adjacent = true;
        break;
      }
    }
    if (adjacent) continue;

    // Place queen
    placement[row][col] = 1;
    usedCols.add(col);
    usedRegions.add(regionId);

    solveQueens(n, regions, row + 1, usedCols, usedRegions, placement, solutions, limit);

    if (solutions.length > limit) {
      // Undo and return early
      placement[row][col] = 0;
      usedCols.delete(col);
      usedRegions.delete(regionId);
      return;
    }

    // Undo
    placement[row][col] = 0;
    usedCols.delete(col);
    usedRegions.delete(regionId);
  }
}

function findSolutions(n: number, regions: number[][], limit = 1): number[][][] {
  const placement: number[][] = Array.from({ length: n }, () => Array(n).fill(0));
  const solutions: number[][][] = [];
  solveQueens(n, regions, 0, new Set(), new Set(), placement, solutions, limit);
  return solutions;
}

function getSolutionColumns(n: number, difficulty: PuzzleDifficulty): number[] {
  const evens = Array.from({ length: Math.ceil(n / 2) }, (_, index) => index * 2);
  const odds = Array.from({ length: Math.floor(n / 2) }, (_, index) => index * 2 + 1);
  return (
    difficulty === "easy"
      ? [...evens, ...odds]
      : difficulty === "medium"
        ? [...odds, ...evens]
        : [...evens.reverse(), ...odds.reverse()]
  );
}

function generateRegionsFromSolution(
  n: number,
  solutionColumns: number[],
  difficulty: PuzzleDifficulty
): number[][] {
  const grid: number[][] = Array.from({ length: n }, () => Array(n).fill(-1));
  const regions: Array<Array<[number, number]>> = [];

  // Seed each connected color section on the known valid queen position.
  for (let row = 0; row < n; row++) {
    const column = solutionColumns[row];
    grid[row][column] = row;
    regions.push([[row, column]]);
  }

  let unassigned = n * n - n;
  const maxRegionSize = n + Math.max(2, Math.floor(n * 0.2));
  while (unassigned > 0) {
    const candidates = regions
      .map((region, regionId) => {
        const frontier = new Set<string>();
        for (const [row, column] of region) {
          for (const [nextRow, nextColumn] of [
            [row + 1, column],
            [row - 1, column],
            [row, column + 1],
            [row, column - 1],
          ]) {
            if (
              nextRow >= 0 &&
              nextRow < n &&
              nextColumn >= 0 &&
              nextColumn < n &&
              grid[nextRow][nextColumn] === -1
            ) {
              frontier.add(`${nextRow},${nextColumn}`);
            }
          }
        }
        return { regionId, region, frontier: Array.from(frontier) };
      })
      .filter(({ frontier }) => frontier.length > 0);
    const balancedCandidates = candidates.filter(
      ({ region }) => region.length < maxRegionSize
    );
    const availableCandidates = balancedCandidates.length > 0 ? balancedCandidates : candidates;

    const candidate =
      difficulty === "easy"
        ? availableCandidates.reduce((smallest, current) =>
            current.region.length < smallest.region.length ? current : smallest
          )
        : difficulty === "hard"
          ? availableCandidates.reduce((smallest, current) =>
              current.region.length < smallest.region.length ? current : smallest
            )
          : availableCandidates[Math.floor(Math.random() * availableCandidates.length)];
    const [row, column] = candidate.frontier[
      difficulty === "easy"
        ? 0
        : Math.floor(Math.random() * candidate.frontier.length)
    ]
      .split(",")
      .map(Number);

    grid[row][column] = candidate.regionId;
    candidate.region.push([row, column]);
    unassigned--;
  }

  return grid;
}

function generateLargePuzzle(n: number, difficulty: PuzzleDifficulty): PuzzleGrid {
  const solutionColumns = getSolutionColumns(n, difficulty);
  return {
    size: n,
    regions: generateRegionsFromSolution(n, solutionColumns, difficulty),
    solution: solutionColumns.map((column) =>
      Array.from({ length: n }, (_, currentColumn) => (currentColumn === column ? 1 : 0))
    ),
    generatedIn: 1,
  };
}

export function generatePuzzle(
  n: number,
  difficulty: PuzzleDifficulty = "medium",
  maxAttempts?: number
): PuzzleGrid | null {
  const defaultAttempts = difficulty === "easy" ? 400 : difficulty === "hard" ? 1600 : 800;
  if (n > 10 && maxAttempts === undefined) {
    return generateLargePuzzle(n, difficulty);
  }

  const attemptLimit = maxAttempts ?? defaultAttempts;

  for (let attempt = 1; attempt <= attemptLimit; attempt++) {
    const regions = generateRandomRegions(n, difficulty);
    const solutions = findSolutions(n, regions, 1);

    if (solutions.length === 1) {
      return {
        size: n,
        regions,
        solution: solutions[0],
        generatedIn: attempt,
      };
    }
  }

  return null;
}

export interface ValidationInput {
  size: number;
  regions: number[][];
  placement: number[][];
}

export interface ValidationOutput {
  correct: boolean;
  errors: string[];
  conflictCells: number[][];
}

export function validateSolution(input: ValidationInput): ValidationOutput {
  const { size: n, regions, placement } = input;
  const errors: string[] = [];
  const conflictCellSet = new Set<string>();

  const addConflict = (r1: number, c1: number, r2?: number, c2?: number) => {
    conflictCellSet.add(`${r1},${c1}`);
    if (r2 !== undefined && c2 !== undefined) {
      conflictCellSet.add(`${r2},${c2}`);
    }
  };

  // Collect queen positions
  const queenPositions: Array<[number, number]> = [];
  for (let i = 0; i < n; i++) {
    for (let j = 0; j < n; j++) {
      if (placement[i][j] === 1) {
        queenPositions.push([i, j]);
      }
    }
  }

  // Check total count
  if (queenPositions.length !== n) {
    errors.push(`Expected ${n} queens, but found ${queenPositions.length}.`);
  }

  // Check rows: exactly one queen per row
  for (let i = 0; i < n; i++) {
    const rowQueens = queenPositions.filter(([r]) => r === i);
    if (rowQueens.length === 0) {
      errors.push(`Row ${i + 1} has no queen.`);
    } else if (rowQueens.length > 1) {
      errors.push(`Row ${i + 1} has more than one queen.`);
      rowQueens.forEach(([r, c]) => addConflict(r, c));
    }
  }

  // Check columns: exactly one queen per column
  for (let j = 0; j < n; j++) {
    const colQueens = queenPositions.filter(([, c]) => c === j);
    if (colQueens.length > 1) {
      errors.push(`Column ${j + 1} has more than one queen.`);
      colQueens.forEach(([r, c]) => addConflict(r, c));
    }
  }

  // Check regions: exactly one queen per region
  const regionQueens: Record<number, Array<[number, number]>> = {};
  for (const [r, c] of queenPositions) {
    const rId = regions[r][c];
    if (!regionQueens[rId]) regionQueens[rId] = [];
    regionQueens[rId].push([r, c]);
  }
  for (let rId = 0; rId < n; rId++) {
    const rq = regionQueens[rId] ?? [];
    if (rq.length === 0) {
      errors.push(`Region ${rId + 1} has no queen.`);
    } else if (rq.length > 1) {
      errors.push(`Region ${rId + 1} has more than one queen.`);
      rq.forEach(([r, c]) => addConflict(r, c));
    }
  }

  // Check adjacency
  for (let i = 0; i < queenPositions.length; i++) {
    for (let j = i + 1; j < queenPositions.length; j++) {
      const [r1, c1] = queenPositions[i];
      const [r2, c2] = queenPositions[j];
      if (Math.abs(r1 - r2) <= 1 && Math.abs(c1 - c2) <= 1) {
        errors.push(`Queens at (${r1 + 1},${c1 + 1}) and (${r2 + 1},${c2 + 1}) are adjacent.`);
        addConflict(r1, c1, r2, c2);
      }
    }
  }

  const conflictCells = Array.from(conflictCellSet).map((s) =>
    s.split(",").map(Number)
  );

  return {
    correct: errors.length === 0 && queenPositions.length === n,
    errors,
    conflictCells,
  };
}
