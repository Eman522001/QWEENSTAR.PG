import { Router, type IRouter } from "express";
import healthRouter from "./health";
import puzzleRouter from "./puzzle";

const router: IRouter = Router();

router.use(healthRouter);
router.use(puzzleRouter);

export default router;
