import { Router, type IRouter } from "express";
import { generatePuzzle, validateSolution } from "../lib/puzzle";
import { GeneratePuzzleQueryParams, ValidateSolutionBody } from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/puzzle", async (req, res): Promise<void> => {
  const parsed = GeneratePuzzleQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const size = parsed.data.size ?? 6;
  const difficulty = parsed.data.difficulty ?? "medium";
  req.log.info({ size, difficulty }, "Generating puzzle");

  const puzzle = generatePuzzle(size, difficulty);
  if (!puzzle) {
    req.log.error({ size, difficulty }, "Failed to generate puzzle with unique solution");
    res.status(500).json({ error: "Could not generate a valid puzzle. Please try again." });
    return;
  }

  req.log.info({ size, difficulty, attempts: puzzle.generatedIn }, "Puzzle generated");
  res.json(puzzle);
});

router.post("/puzzle/validate", async (req, res): Promise<void> => {
  const parsed = ValidateSolutionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const result = validateSolution(parsed.data);
  res.json(result);
});

export default router;
