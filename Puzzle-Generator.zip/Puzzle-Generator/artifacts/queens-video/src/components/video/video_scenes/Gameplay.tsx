import { motion } from 'framer-motion';
import { useEffect, useState } from 'react';

const Crown = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="currentColor" className={className}>
    <path d="M5 16L3 5L8.5 10L12 2L15.5 10L21 5L19 16H5ZM19 19C19 19.6 18.6 20 18 20H6C5.4 20 5 19.6 5 19V18H19V19Z" />
  </svg>
);

export function Gameplay() {
  const [phase, setPhase] = useState(0);

  useEffect(() => {
    const timers = [
      setTimeout(() => setPhase(1), 500),
      setTimeout(() => setPhase(2), 2000),
      setTimeout(() => setPhase(3), 3500),
      setTimeout(() => setPhase(4), 5000),
    ];
    return () => timers.forEach(t => clearTimeout(t));
  }, []);

  return (
    <motion.div 
      className="absolute inset-0 flex items-center justify-center z-10"
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 1.1 }}
      transition={{ duration: 0.8, ease: "easeInOut" }}
    >
      <div className="w-[80vw] h-[70vh] bg-white rounded-2xl shadow-2xl overflow-hidden flex flex-col border border-secondary/10 relative">
        <div className="h-16 border-b border-secondary/10 flex items-center px-8 bg-bg-light">
          <div className="flex gap-2">
            <div className="w-3 h-3 rounded-full bg-error" />
            <div className="w-3 h-3 rounded-full bg-warning" />
            <div className="w-3 h-3 rounded-full bg-success" />
          </div>
          <div className="mx-auto font-display font-bold text-secondary text-xl">Queens Puzzle</div>
        </div>

        <div className="flex-1 p-12 flex justify-center items-center bg-bg-muted/50">
          <div className="w-[40vh] h-[40vh] grid grid-cols-5 grid-rows-5 rounded-lg overflow-hidden shadow-lg border border-secondary/20">
            {Array.from({ length: 25 }).map((_, i) => (
              <div 
                key={i} 
                className="border-[0.5px] border-secondary/10 relative cursor-pointer"
                style={{
                  backgroundColor: i % 2 === 0 ? 'var(--color-pastel-pink)' : 'var(--color-pastel-yellow)'
                }}
              >
                {((i === 2 && phase >= 1) || (i === 10 && phase >= 2) || (i === 24 && phase >= 3)) && (
                  <motion.div 
                    className="absolute inset-0 flex items-center justify-center text-secondary"
                    initial={{ scale: 0, rotate: -45 }}
                    animate={{ scale: 1, rotate: 0 }}
                    transition={{ type: "spring", stiffness: 300, damping: 20 }}
                  >
                    <Crown className="w-[60%] h-[60%]" />
                  </motion.div>
                )}
                
                {phase >= 4 && i !== 2 && i !== 10 && i !== 24 && (
                  <motion.div
                    className="absolute inset-0 flex items-center justify-center font-bold text-secondary/30"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                  >
                    X
                  </motion.div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </motion.div>
  );
}
