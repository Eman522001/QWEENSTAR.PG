import { motion } from 'framer-motion';
import { useEffect, useState } from 'react';

const Crown = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="currentColor" className={className}>
    <path d="M5 16L3 5L8.5 10L12 2L15.5 10L21 5L19 16H5ZM19 19C19 19.6 18.6 20 18 20H6C5.4 20 5 19.6 5 19V18H19V19Z" />
  </svg>
);

export function Rules() {
  const [phase, setPhase] = useState(0);

  useEffect(() => {
    const timers = [
      setTimeout(() => setPhase(1), 800), // First queen
      setTimeout(() => setPhase(2), 2000), // Lines
      setTimeout(() => setPhase(3), 4500), // Text: One per row
      setTimeout(() => setPhase(4), 6000), // Second queen, invalid
      setTimeout(() => setPhase(5), 7500), // Second queen moves
    ];
    return () => timers.forEach(t => clearTimeout(t));
  }, []);

  return (
    <motion.div 
      className="absolute inset-0 flex items-center justify-center z-10"
      initial={{ opacity: 0, scale: 1.05 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, x: -100 }}
      transition={{ duration: 0.8, ease: "easeInOut" }}
    >
      <div className="absolute left-[10vw] w-[35vw]">
        <motion.h2 
          className="text-[4vw] font-display font-bold leading-tight"
          initial={{ opacity: 0, y: 30 }}
          animate={phase >= 1 ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
        >
          Simple Rules.
        </motion.h2>
        <div className="mt-8 space-y-6">
          <motion.div 
            className="flex items-center gap-4"
            initial={{ opacity: 0, x: -20 }}
            animate={phase >= 3 ? { opacity: 1, x: 0 } : { opacity: 0, x: -20 }}
          >
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-xl">1</div>
            <p className="text-[2vw] font-medium text-secondary">One per row & column</p>
          </motion.div>
          <motion.div 
            className="flex items-center gap-4"
            initial={{ opacity: 0, x: -20 }}
            animate={phase >= 4 ? { opacity: 1, x: 0 } : { opacity: 0, x: -20 }}
          >
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-xl">2</div>
            <p className="text-[2vw] font-medium text-secondary">No touching</p>
          </motion.div>
        </div>
      </div>

      <div className="absolute right-[10vw] w-[40vw] h-[40vw] max-w-[500px] max-h-[500px]">
        <div className="absolute inset-0 grid grid-cols-4 grid-rows-4 bg-white rounded-lg shadow-xl overflow-hidden border border-secondary/20">
          {Array.from({ length: 16 }).map((_, i) => (
            <div key={i} className="border-[0.5px] border-secondary/10 relative">
              {/* Region colors */}
              <div className="absolute inset-0" style={{
                backgroundColor: i < 4 ? 'var(--color-pastel-blue)' : i < 8 ? 'var(--color-pastel-orange)' : 'var(--color-pastel-green)'
              }} />
              
              {/* Queen 1 */}
              {i === 5 && (
                <motion.div 
                  className="absolute inset-0 flex items-center justify-center text-secondary"
                  initial={{ scale: 0, opacity: 0 }}
                  animate={phase >= 1 ? { scale: 1, opacity: 1 } : { scale: 0, opacity: 0 }}
                  transition={{ type: "spring", stiffness: 400, damping: 25 }}
                >
                  <Crown className="w-[60%] h-[60%]" />
                </motion.div>
              )}

              {/* Queen 2 - invalid then valid */}
              {i === 6 && phase >= 4 && phase < 5 && (
                <motion.div 
                  className="absolute inset-0 flex items-center justify-center text-error"
                  initial={{ scale: 0, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 0, opacity: 0 }}
                  transition={{ type: "spring" }}
                >
                  <Crown className="w-[60%] h-[60%]" />
                </motion.div>
              )}
              {i === 11 && phase >= 5 && (
                <motion.div 
                  className="absolute inset-0 flex items-center justify-center text-secondary"
                  initial={{ scale: 0, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ type: "spring" }}
                >
                  <Crown className="w-[60%] h-[60%]" />
                </motion.div>
              )}
            </div>
          ))}

          {/* Row/Col/Diag Lines */}
          {phase >= 2 && (
            <>
              <motion.div className="absolute top-[37.5%] left-0 right-0 h-[2px] bg-error/50 z-10" initial={{ scaleX: 0 }} animate={{ scaleX: 1 }} transition={{ duration: 0.5 }} />
              <motion.div className="absolute top-0 bottom-0 left-[37.5%] w-[2px] bg-error/50 z-10" initial={{ scaleY: 0 }} animate={{ scaleY: 1 }} transition={{ duration: 0.5 }} />
            </>
          )}
        </div>
      </div>
    </motion.div>
  );
}
