import { motion } from 'framer-motion';
import { useEffect, useState } from 'react';

export function Intro() {
  const [phase, setPhase] = useState(0);

  useEffect(() => {
    const timers = [
      setTimeout(() => setPhase(1), 500),
      setTimeout(() => setPhase(2), 1500),
      setTimeout(() => setPhase(3), 2800),
    ];
    return () => timers.forEach(t => clearTimeout(t));
  }, []);

  return (
    <motion.div 
      className="absolute inset-0 flex items-center justify-center z-10"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.8 }}
    >
      <div className="relative w-[40vw] h-[40vw] max-w-[600px] max-h-[600px]">
        {/* Grid base */}
        <motion.div 
          className="absolute inset-0 grid grid-cols-5 grid-rows-5 border-2 border-secondary/20 shadow-2xl bg-white rounded-lg overflow-hidden"
          initial={{ rotateX: 60, rotateZ: -45, scale: 0.5, y: 100, opacity: 0 }}
          animate={{ rotateX: 0, rotateZ: 0, scale: 1, y: 0, opacity: 1 }}
          transition={{ duration: 1.5, ease: [0.16, 1, 0.3, 1] }}
        >
          {Array.from({ length: 25 }).map((_, i) => (
            <motion.div 
              key={i} 
              className="border-[0.5px] border-secondary/10"
              initial={{ backgroundColor: '#ffffff' }}
              animate={
                phase >= 1 ? { 
                  backgroundColor: i % 3 === 0 ? 'var(--color-pastel-orange)' : i % 5 === 0 ? 'var(--color-pastel-pink)' : i % 2 === 0 ? 'var(--color-pastel-blue)' : 'var(--color-pastel-yellow)'
                } : { backgroundColor: '#ffffff' }
              }
              transition={{ duration: 0.5, delay: phase >= 1 ? i * 0.02 : 0 }}
            />
          ))}
        </motion.div>
      </div>

      <motion.div 
        className="absolute top-1/4 left-[10vw]"
        initial={{ opacity: 0, x: -50 }}
        animate={phase >= 2 ? { opacity: 1, x: 0 } : { opacity: 0, x: -50 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
      >
        <h1 className="text-[6vw] font-display font-bold leading-none text-secondary">
          QUEENS
        </h1>
        <h1 className="text-[6vw] font-display font-bold leading-none text-primary">
          PUZZLE
        </h1>
        <motion.p 
          className="mt-4 text-[1.5vw] text-secondary/70 font-medium"
          initial={{ opacity: 0 }}
          animate={phase >= 2 ? { opacity: 1 } : { opacity: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
        >
          The Elegant Logic Game
        </motion.p>
      </motion.div>
    </motion.div>
  );
}
