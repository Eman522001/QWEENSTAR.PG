import { motion } from 'framer-motion';
import { useEffect, useState } from 'react';

export function Solver() {
  const [phase, setPhase] = useState(0);

  useEffect(() => {
    const timers = [
      setTimeout(() => setPhase(1), 1000),
      setTimeout(() => setPhase(2), 5000),
      setTimeout(() => setPhase(3), 9000),
    ];
    return () => timers.forEach(t => clearTimeout(t));
  }, []);

  return (
    <motion.div 
      className="absolute inset-0 flex items-center justify-center z-10 bg-bg-dark text-white"
      initial={{ opacity: 0, y: 100 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -100 }}
      transition={{ duration: 0.8, ease: "easeInOut" }}
    >
      <div className="absolute inset-0 overflow-hidden font-mono opacity-20 pointer-events-none">
        {Array.from({ length: 30 }).map((_, i) => (
          <motion.div 
            key={i}
            className="whitespace-nowrap text-sm"
            initial={{ x: -1000 }}
            animate={{ x: 1000 }}
            transition={{ duration: 15 + Math.random() * 10, repeat: Infinity, ease: "linear", delay: Math.random() * 5 }}
            style={{ y: i * 30 }}
          >
            {`function solveBoard(board, col) { if (col >= N) return true; for (let i = 0; i < N; i++) { ... } }`}
          </motion.div>
        ))}
      </div>

      <div className="relative w-full max-w-6xl mx-auto flex flex-col items-center">
        <motion.h2 
          className="text-[5vw] font-display font-bold text-center"
          initial={{ opacity: 0, y: -20 }}
          animate={phase >= 1 ? { opacity: 1, y: 0 } : { opacity: 0, y: -20 }}
        >
          Infinite Unique Puzzles.
        </motion.h2>
        
        <motion.div 
          className="mt-8 text-center"
          initial={{ opacity: 0 }}
          animate={phase >= 2 ? { opacity: 1 } : { opacity: 0 }}
        >
          <p className="text-[2vw] text-white/70">Generated instantly.</p>
          <p className="text-[2vw] text-white/70">Guaranteed one solution.</p>
        </motion.div>

        <div className="mt-16 w-[60vw] max-w-3xl h-[200px] relative border-l-2 border-b-2 border-white/20">
           {/* Chart simulating backtracking complexity / speed */}
           <motion.svg className="absolute inset-0 w-full h-full overflow-visible" preserveAspectRatio="none">
             <motion.path 
               d="M 0,200 Q 100,180 200,100 T 400,150 T 600,50 T 800,180 T 1000,20"
               fill="none"
               stroke="var(--color-primary)"
               strokeWidth="4"
               initial={{ pathLength: 0 }}
               animate={phase >= 1 ? { pathLength: 1 } : { pathLength: 0 }}
               transition={{ duration: 8, ease: "linear" }}
             />
           </motion.svg>
        </div>
      </div>
    </motion.div>
  );
}
