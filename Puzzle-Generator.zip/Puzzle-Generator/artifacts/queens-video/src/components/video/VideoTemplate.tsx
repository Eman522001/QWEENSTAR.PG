import { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useVideoPlayer } from '@/lib/video';
import { Intro } from './video_scenes/Intro';
import { Rules } from './video_scenes/Rules';
import { Solver } from './video_scenes/Solver';
import { Gameplay } from './video_scenes/Gameplay';
import { Outro } from './video_scenes/Outro';

export const SCENE_DURATIONS: Record<string, number> = {
  intro: 4000,
  rules: 10000,
  solver: 14000,
  gameplay: 7000,
  outro: 10000,
};

const SCENE_COMPONENTS: Record<string, React.ComponentType> = {
  intro: Intro,
  rules: Rules,
  solver: Solver,
  gameplay: Gameplay,
  outro: Outro,
};

export default function VideoTemplate({
  durations = SCENE_DURATIONS,
  loop = true,
  onSceneChange,
}: {
  durations?: Record<string, number>;
  loop?: boolean;
  onSceneChange?: (sceneKey: string) => void;
} = {}) {
  const { currentScene, currentSceneKey } = useVideoPlayer({ durations, loop });

  useEffect(() => {
    onSceneChange?.(currentSceneKey);
  }, [currentSceneKey, onSceneChange]);

  const baseSceneKey = currentSceneKey.replace(/_r[12]$/, '') as keyof typeof SCENE_DURATIONS;
  const sceneIndex = Object.keys(SCENE_DURATIONS).indexOf(baseSceneKey);
  const SceneComponent = SCENE_COMPONENTS[baseSceneKey];

  return (
    <div className="relative w-full h-screen overflow-hidden bg-bg-light font-body">

      {/* Persistent Background Layer */}
      <div className="absolute inset-0 pointer-events-none z-0">
        <motion.div
          className="absolute w-[80vw] h-[80vw] rounded-full blur-[100px] opacity-30"
          style={{ background: 'var(--color-pastel-purple)' }}
          animate={{
            x: sceneIndex === 4 ? '10vw' : ['-20vw', '20vw', '-20vw'],
            y: sceneIndex === 4 ? '10vh' : ['-20vh', '10vh', '-20vh'],
            scale: sceneIndex === 4 ? 1.5 : [1, 1.2, 1],
          }}
          transition={{ duration: 15, repeat: sceneIndex === 4 ? 0 : Infinity, ease: 'easeInOut' }}
        />
        <motion.div
          className="absolute w-[60vw] h-[60vw] rounded-full blur-[100px] opacity-30 right-0 bottom-0"
          style={{ background: 'var(--color-pastel-orange)' }}
          animate={{
            x: sceneIndex === 4 ? '-10vw' : ['20vw', '-10vw', '20vw'],
            y: sceneIndex === 4 ? '-10vh' : ['20vh', '-10vh', '20vh'],
            scale: sceneIndex === 4 ? 1.5 : [1, 1.3, 1],
          }}
          transition={{ duration: 12, repeat: sceneIndex === 4 ? 0 : Infinity, ease: 'easeInOut' }}
        />

        {/* Subtle grid pattern overlay */}
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage:
              'linear-gradient(var(--color-secondary) 1px, transparent 1px), linear-gradient(90deg, var(--color-secondary) 1px, transparent 1px)',
            backgroundSize: '4vw 4vw',
          }}
        />
      </div>

      <AnimatePresence mode="popLayout">
        {SceneComponent && <SceneComponent key={currentSceneKey} />}
      </AnimatePresence>
    </div>
  );
}
