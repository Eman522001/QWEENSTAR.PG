import { useState, useEffect, useCallback } from "react";
import { useGeneratePuzzle, useValidateSolution } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Play, CheckCircle2, RotateCcw, Download, ImageDown } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

// Cell states
const EMPTY = 0;
const MARK_X = 1;
const QUEEN = 2;

const REGION_COLORS = [
  "bg-[#BFECAC] text-[#14532D]",
  "bg-[#FFDE59] text-[#713F12]",
  "bg-[#CFCF5A] text-[#3F6212]",
  "bg-[#FF9999] text-[#7F1D1D]",
  "bg-[#BF86FA] text-[#4C1D95]",
  "bg-[#99FFCE] text-[#134E4A]",
  "bg-[#D3FF99] text-[#365314]",
  "bg-[#FFEB99] text-[#713F12]",
  "bg-[#E17AD3] text-[#581C87]",
  "bg-[#BEE6FE] text-[#164E63]",
  "bg-[#21D19F] text-[#115E59]",
  "bg-[#F373B6] text-[#831843]",
  "bg-[#60A5F9] text-[#1E3A8A]",
  "bg-[#F9CC15] text-[#713F12]",
  "bg-[#B4B4B4] text-[#374151]",
  "bg-[#FB923C] text-[#7C2D12]",
  "bg-[#F93D3A] text-[#7F1D1D]",
  "bg-[#C995F2] text-[#581C87]",
  "bg-[#3B28CC] text-white",
  "bg-[#4C2C69] text-white",
];

const REGION_HEX = [
  "#BFECAC", "#FFDE59", "#CFCF5A", "#FF9999", "#BF86FA",
  "#99FFCE", "#D3FF99", "#FFEB99", "#E17AD3", "#BEE6FE",
  "#21D19F", "#F373B6", "#60A5F9", "#F9CC15", "#B4B4B4",
  "#FB923C", "#F93D3A", "#C995F2", "#3B28CC", "#4C2C69",
];

type PuzzleDifficulty = "easy" | "medium" | "hard";

function ThreeDStar({ className }: { className?: string }) {
  return (
    <span className={cn("three-d-star inline-block leading-none", className)} aria-hidden="true">
      ★
    </span>
  );
}

function drawThreeDStar(
  ctx: CanvasRenderingContext2D,
  centerX: number,
  centerY: number,
  outerRadius: number
) {
  const innerRadius = outerRadius * 0.44;

  ctx.save();
  ctx.translate(centerX, centerY + outerRadius * 0.06);
  ctx.shadowColor = "rgba(91, 48, 0, 0.42)";
  ctx.shadowBlur = outerRadius * 0.16;
  ctx.shadowOffsetY = outerRadius * 0.14;

  const gradient = ctx.createLinearGradient(0, -outerRadius, 0, outerRadius);
  gradient.addColorStop(0, "#FFF7B8");
  gradient.addColorStop(0.28, "#FFE16A");
  gradient.addColorStop(0.66, "#F5B51B");
  gradient.addColorStop(1, "#B96A00");

  ctx.beginPath();
  for (let point = 0; point < 10; point++) {
    const radius = point % 2 === 0 ? outerRadius : innerRadius;
    const angle = -Math.PI / 2 + (point * Math.PI) / 5;
    const x = Math.cos(angle) * radius;
    const y = Math.sin(angle) * radius;
    if (point === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.closePath();
  ctx.fillStyle = gradient;
  ctx.fill();
  ctx.shadowColor = "transparent";
  ctx.strokeStyle = "rgba(126, 71, 0, 0.72)";
  ctx.lineWidth = Math.max(1.5, outerRadius * 0.045);
  ctx.stroke();
  ctx.restore();
}

export default function Home() {
  const [size, setSize] = useState<number>(6);
  const [difficulty, setDifficulty] = useState<PuzzleDifficulty>("medium");
  const { data: puzzle, isLoading, isFetching, refetch } = useGeneratePuzzle({ size, difficulty });
  // placement[r][c]: 0=empty, 1=X mark, 2=queen
  const [placement, setPlacement] = useState<number[][]>([]);
  const [startTime, setStartTime] = useState<number>(0);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [isWon, setIsWon] = useState(false);

  const validateMutation = useValidateSolution();

  useEffect(() => {
    if (puzzle) {
      setPlacement(Array(puzzle.size).fill(0).map(() => Array(puzzle.size).fill(EMPTY)));
      setStartTime(Date.now());
      setIsWon(false);
    }
  }, [puzzle]);

  useEffect(() => {
    if (!startTime || isWon) return;
    const interval = setInterval(() => setCurrentTime(Date.now()), 1000);
    return () => clearInterval(interval);
  }, [startTime, isWon]);

  // 1 click → X, 2nd click → Queen, 3rd click → empty
  const handleCellClick = (r: number, c: number) => {
    if (isWon) return;
    setPlacement((prev) => {
      const next = prev.map((row) => [...row]);
      next[r][c] = (next[r][c] + 1) % 3;
      return next;
    });
  };

  const checkSolution = () => {
    if (!puzzle) return;
    const queenPlacement = placement.map((row) => row.map((v) => (v === QUEEN ? 1 : 0)));
    const totalQueens = queenPlacement.reduce((acc, row) => acc + row.reduce((a, b) => a + b, 0), 0);
    if (totalQueens !== puzzle.size) {
      toast.error(`ضعي ${puzzle.size} ملكات بالضبط. وضعتِ ${totalQueens} حتى الآن.`);
      return;
    }
    validateMutation.mutate(
      { data: { size: puzzle.size, regions: puzzle.regions, placement: queenPlacement } },
      {
        onSuccess: (result) => {
          if (result.correct) {
            setIsWon(true);
            toast.success("تم حل اللغز!", { icon: <ThreeDStar className="text-xl" /> });
          } else {
            toast.error("الحل غير صحيح. حاولي مجدداً!", {
              description: result.errors[0] || "هناك تعارض في وضع الملكات.",
            });
          }
        },
      }
    );
  };

  const getConflicts = () => {
    const conflicts = new Set<string>();
    if (!puzzle || placement.length !== puzzle.size) return conflicts;
    for (let r = 0; r < puzzle.size; r++) {
      for (let c = 0; c < puzzle.size; c++) {
        if (placement[r]?.[c] === QUEEN) {
          for (let i = 0; i < puzzle.size; i++) {
            for (let j = 0; j < puzzle.size; j++) {
              if ((i !== r || j !== c) && placement[i][j] === QUEEN) {
                const sameRow = i === r;
                const sameCol = j === c;
                const sameRegion = puzzle.regions[r][c] === puzzle.regions[i][j];
                const adjacent = Math.abs(i - r) <= 1 && Math.abs(j - c) <= 1;
                if (sameRow || sameCol || sameRegion || adjacent) {
                  conflicts.add(`${r},${c}`);
                  conflicts.add(`${i},${j}`);
                }
              }
            }
          }
        }
      }
    }
    return conflicts;
  };

  const downloadPuzzle = useCallback(
    (solved: boolean) => {
      if (!puzzle) return;
      const CELL = 100;
      const GAP = 3;
      const PAD = 12;
      const RADIUS = 6;
      const N = puzzle.size;
      const inner = N * CELL + (N - 1) * GAP;
      const total = inner + PAD * 2;

      const canvas = document.createElement("canvas");
      canvas.width = total;
      canvas.height = total;
      const ctx = canvas.getContext("2d")!;

      // Background
      ctx.fillStyle = "#F8F6F2";
      ctx.fillRect(0, 0, total, total);

      for (let r = 0; r < N; r++) {
        for (let c = 0; c < N; c++) {
          const regionId = puzzle.regions[r][c];
          const x = PAD + c * (CELL + GAP);
          const y = PAD + r * (CELL + GAP);
           const hex = REGION_HEX[regionId];

          // Cell background
          ctx.fillStyle = hex;
          ctx.beginPath();
          ctx.roundRect(x, y, CELL, CELL, RADIUS);
          ctx.fill();

          if (solved) {
             const val = solved
               ? puzzle.solution[r]?.[c]
                 ? QUEEN
                 : EMPTY
               : placement[r]?.[c] ?? EMPTY;
            if (val === QUEEN) {
              drawThreeDStar(ctx, x + CELL / 2, y + CELL / 2, CELL * 0.31);
            } else if (val === MARK_X) {
              const margin = CELL * 0.28;
              ctx.strokeStyle = "rgba(0,0,0,0.30)";
              ctx.lineWidth = CELL * 0.09;
              ctx.lineCap = "round";
              ctx.beginPath();
              ctx.moveTo(x + margin, y + margin);
              ctx.lineTo(x + CELL - margin, y + CELL - margin);
              ctx.moveTo(x + CELL - margin, y + margin);
              ctx.lineTo(x + margin, y + CELL - margin);
              ctx.stroke();
            }
          }
        }
      }

      const a = document.createElement("a");
      a.href = canvas.toDataURL("image/png");
      a.download = solved ? "queens-solved.png" : "queens-empty.png";
      a.click();
    },
    [puzzle, placement]
  );

  const conflicts = getConflicts();
  const elapsedSeconds =
    startTime > 0 ? Math.max(0, Math.floor(((currentTime || Date.now()) - startTime) / 1000)) : 0;
  const mins = Math.floor(elapsedSeconds / 60).toString().padStart(2, "0");
  const secs = (elapsedSeconds % 60).toString().padStart(2, "0");

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4 sm:p-8 font-sans relative overflow-hidden">
      <div className="max-w-xl w-full flex flex-col gap-8 relative z-10">

        {/* Header */}
        <header className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <h1 className="text-4xl font-bold tracking-tight text-primary flex items-center gap-3">
              Queens
              <ThreeDStar className="text-3xl text-primary/40" />
            </h1>
            <p className="text-muted-foreground mt-1 font-medium">A puzzle of logic and color</p>
          </div>

          <div className="flex flex-wrap items-center justify-end gap-2 sm:gap-3">
            <Select
              value={size.toString()}
              onValueChange={(val) => setSize(parseInt(val))}
              disabled={isLoading || isFetching}
            >
              <SelectTrigger className="w-[5.5rem] bg-card">
                <SelectValue placeholder="Size" />
              </SelectTrigger>
              <SelectContent>
                {Array.from({ length: 16 }, (_, index) => index + 5).map((boardSize) => (
                  <SelectItem key={boardSize} value={boardSize.toString()}>
                    {boardSize} × {boardSize}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select
              value={difficulty}
              onValueChange={(value) => setDifficulty(value as PuzzleDifficulty)}
              disabled={isLoading || isFetching}
            >
              <SelectTrigger className="w-[6.5rem] bg-card">
                <SelectValue placeholder="Difficulty" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="easy">Easy</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="hard">Hard</SelectItem>
              </SelectContent>
            </Select>

            <Button
              variant="outline"
              size="icon"
              onClick={() => refetch()}
              disabled={isLoading || isFetching}
              className="bg-card"
            >
              <RotateCcw className={cn("w-4 h-4", (isLoading || isFetching) && "animate-spin")} />
            </Button>
          </div>
        </header>

        {/* Game Area */}
        <div className="relative">
          <AnimatePresence mode="wait">
            {isLoading || !puzzle ? (
              <motion.div
                key="loading"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="aspect-square w-full max-w-[500px] mx-auto bg-card border rounded-xl flex items-center justify-center shadow-sm"
              >
                <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
              </motion.div>
            ) : (
              <motion.div
                key="board"
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-card p-2 sm:p-4 rounded-xl border shadow-sm mx-auto w-full max-w-[500px]"
              >
                {/* Stats Bar */}
                <div className="flex justify-between items-center mb-4 px-2 font-mono text-sm text-muted-foreground">
                  <span className="bg-primary/5 px-2 py-1 rounded text-primary">
                    {mins}:{secs}
                  </span>
                  <div className="text-xs opacity-60">Gen {puzzle.generatedIn} attempts</div>
                </div>

                {/* Board */}
                <div
                  className="grid gap-[2px] sm:gap-1 w-full bg-border border-4 border-border rounded-lg overflow-hidden"
                  style={{ gridTemplateColumns: `repeat(${puzzle.size}, minmax(0, 1fr))` }}
                >
                  {puzzle.regions.map((row, r) =>
                    row.map((regionId, c) => {
                       const colorClass = REGION_COLORS[regionId];
                      const cellVal = placement[r]?.[c] ?? EMPTY;
                      const hasConflict = conflicts.has(`${r},${c}`);

                      return (
                        <div
                          key={`${r}-${c}`}
                          onClick={() => handleCellClick(r, c)}
                          className={cn(
                            "aspect-square flex items-center justify-center cursor-pointer transition-all duration-150 select-none",
                            colorClass,
                            "hover:brightness-95 active:scale-95",
                            hasConflict &&
                              "ring-inset ring-2 ring-destructive bg-destructive/10 !text-destructive"
                          )}
                        >
                          <AnimatePresence mode="wait">
                            {cellVal === QUEEN && (
                              <motion.div
                                key="star"
                                initial={{ scale: 0, rotate: -15 }}
                                animate={{ scale: 1, rotate: 0 }}
                                exit={{ scale: 0, rotate: 15 }}
                                transition={{ duration: 0.15 }}
                                className={cn(
                                  "drop-shadow-sm leading-none",
                                  puzzle.size >= 16
                                    ? "text-base sm:text-2xl"
                                    : puzzle.size >= 11
                                      ? "text-xl sm:text-3xl"
                                      : "text-2xl sm:text-4xl"
                                )}
                                >
                                  <ThreeDStar className="h-full w-full" />
                                </motion.div>
                            )}
                            {cellVal === MARK_X && (
                              <motion.div
                                key="x"
                                initial={{ scale: 0, opacity: 0 }}
                                animate={{ scale: 1, opacity: 1 }}
                                exit={{ scale: 0, opacity: 0 }}
                                transition={{ duration: 0.12 }}
                                className="text-base sm:text-xl font-bold opacity-40 leading-none"
                              >
                                ✕
                              </motion.div>
                            )}
                          </AnimatePresence>
                        </div>
                      );
                    })
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Win Overlay */}
          <AnimatePresence>
            {isWon && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="absolute inset-0 z-20 flex items-center justify-center bg-background/80 backdrop-blur-sm rounded-xl"
              >
                <div className="bg-card border p-8 rounded-2xl shadow-xl text-center flex flex-col items-center max-w-[320px] w-full">
                  <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4 text-primary">
                    <ThreeDStar className="text-3xl" />
                  </div>
                  <h2 className="text-2xl font-bold text-foreground mb-2">Magnificent</h2>
                  <p className="text-muted-foreground mb-6">
                    You solved the {puzzle?.size}×{puzzle?.size} puzzle in {mins}:{secs}.
                  </p>

                  <Button onClick={() => refetch()} className="w-full gap-2" size="lg">
                    <Play className="w-4 h-4" /> Next Puzzle
                  </Button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Footer Actions */}
        <div className="flex flex-col items-center gap-3">
          <p className="text-xs text-muted-foreground/60">نقرة واحدة = ✕  •  نقرتان = ★  •  ثلاث نقرات = مسح</p>
          <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
            <Button
              variant="outline"
              className="w-full sm:w-auto gap-2"
              onClick={() => downloadPuzzle(false)}
              disabled={!puzzle || isLoading || isFetching}
            >
              <ImageDown className="w-4 h-4" />
              تحميل اللغز فارغاً
            </Button>
            <Button
              variant="outline"
              className="w-full sm:w-auto gap-2"
              onClick={() => downloadPuzzle(true)}
              disabled={!puzzle || isLoading || isFetching}
            >
              <Download className="w-4 h-4" />
              تحميل اللغز محلولاً
            </Button>
          </div>
          <Button
            size="lg"
            className="w-full sm:w-auto min-w-[200px] gap-2 shadow-sm"
            onClick={checkSolution}
            disabled={
              isLoading || isFetching || isWon || placement.length === 0 || validateMutation.isPending
            }
          >
            {validateMutation.isPending ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <CheckCircle2 className="w-4 h-4" />
            )}
            Check Solution
          </Button>
        </div>
      </div>
    </div>
  );
}
